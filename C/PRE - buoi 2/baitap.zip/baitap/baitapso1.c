#include <stdio.h>

int main() {
    int number=100;
    printf("\n%d",number);
    printf("\n%d",number+200);
    return 0;
}